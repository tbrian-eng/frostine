from django.apps import AppConfig


class FrostinegraphicsConfig(AppConfig):
    name = 'frostinegraphics'
