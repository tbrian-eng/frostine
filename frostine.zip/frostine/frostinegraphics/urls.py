from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('Branding/', views.Corporate_Branding, name="Corporate Branding"),
    path('Services/', views.Design_Services, name="Design Services"),
    path('Signs&Banners/', views.Signs_Banners, name="Signs and Banners"),
    path('Printing/', views.Printing_Finishing, name="Printing and Finishing"),
    path('Products/', views.Promotional_Products, name="Promotional Products"),
    path('About/', views.About_Us, name="About Us"),
]