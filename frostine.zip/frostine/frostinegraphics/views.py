from django.shortcuts import render
from .models import*

# Create your views here.
def home(request):
    products = Product.objects.all()
    context = {'products' : products}

    return render(request, 'frostinegraphics/home.html')

def Corporate_Branding(request):
    return render(request, 'frostinegraphics/branding.html')

def Design_Services(request):
    return render(request, 'frostinegraphics/services.html')

def Signs_Banners(request):
    return render(request, 'frostinegraphics/banners.html')

def Printing_Finishing(request):
    return render(request, 'frostinegraphics/printing.html')

def Promotional_Products(request):
    return render(request, 'frostinegraphics/products.html')

def About_Us(request):
    return render(request, 'frostinegraphics/about.html')